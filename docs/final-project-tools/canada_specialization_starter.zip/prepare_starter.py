#!/usr/bin/env python3
"""Make a compact, auditable course extract; does not solve the assignment."""
from pathlib import Path
import hashlib
import json
import zipfile
import pandas as pd

ROOT = Path(__file__).resolve().parent
COL = 'North American Industry Classification System (NAICS)'
SECTORS = [
    'Agriculture [111-112, 1100, 1151-1152]',
    'Forestry, fishing, mining, quarrying, oil and gas [21, 113-114, 1153, 2100]',
    'Utilities [22]', 'Construction [23]', 'Manufacturing [31-33]',
    'Wholesale and retail trade [41, 44-45]', 'Transportation and warehousing [48-49]',
    'Finance, insurance, real estate, rental and leasing [52, 53]',
    'Professional, scientific and technical services [54]',
    'Business, building and other support services [55, 56]',
    'Educational services [61]', 'Health care and social assistance [62]',
    'Information, culture and recreation [51, 71]', 'Accommodation and food services [72]',
    'Other services (except public administration) [81]', 'Public administration [91]'
]

def main():
    archive = ROOT / 'raw/14100023-eng.zip'
    with zipfile.ZipFile(archive) as z:
        with z.open('14100023.csv') as f:
            d = pd.read_csv(f, encoding='utf-8-sig', low_memory=False)
    filters = {'Labour force characteristics': 'Employment', 'Gender': 'Total - Gender',
               'Age group': '15 years and over', 'UOM': 'Persons in thousands',
               'SCALAR_FACTOR': 'thousands'}
    for col, value in filters.items(): d = d[d[col].eq(value)]
    d = d[d.REF_DATE.between(2000, 2025)]
    columns = ['REF_DATE', 'GEO', COL, 'VALUE', 'UOM', 'SCALAR_FACTOR', 'STATUS', 'SYMBOL', 'VECTOR']
    mapping = {'REF_DATE': 'year', 'GEO': 'geography', COL: 'industry', 'VALUE': 'employment_thousands',
               'UOM': 'unit', 'SCALAR_FACTOR': 'scalar_factor', 'STATUS': 'status',
               'SYMBOL': 'symbol', 'VECTOR': 'vector'}
    s = d[d[COL].isin(SECTORS)][columns].rename(columns=mapping).sort_values(['geography','industry','year'])
    totals = d[d[COL].eq('Total, all industries')][columns].rename(columns=mapping).sort_values(['geography','year'])
    assert len(s) == 11*16*26
    assert not s.duplicated(['year','geography','industry']).any()
    required = s[s.year.between(2010,2024)]
    assert required.employment_thousands.notna().all()
    assert required.employment_thousands.gt(0).all()
    package = ROOT / 'starter'; package.mkdir(exist_ok=True)
    s.to_csv(package/'provincial_industry_employment_2000_2025.csv',index=False)
    totals.to_csv(package/'provincial_employment_totals_2000_2025.csv',index=False)
    sums = required.groupby(['geography','year']).employment_thousands.sum()
    total = totals.set_index(['geography','year']).employment_thousands
    rounding_gap = (100*(sums/total.loc[sums.index]-1)).abs().max()
    metadata = json.loads((ROOT/'raw/source_metadata.json').read_text())
    metadata.update({'table_title':'Labour force characteristics by industry, annual (x 1,000)',
        'table_url':'https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1410002301',
        'filters':filters,'industry_partition':SECTORS,
        'course_extract_years':[2000,2025],'required_assignment_years':[2010,2024],
        'data_dictionary':{'year':'calendar year, annual estimate','geography':'Canada or province; no territories',
          'industry':'16 mutually exclusive broad published groups; do not add parent/child groups',
          'employment_thousands':'published estimate, thousands of employed persons, not jobs/payroll or hours',
          'unit':'original published units','scalar_factor':'already thousands; do not multiply twice',
          'status':'x means suppressed; empty is not a quality guarantee',
          'symbol':'original source symbol, if any','vector':'Statistics Canada series identifier'},
        'verification':{'required_window_rows':len(required),'duplicate_keys':0,
          'missing_required_window':0,'nonpositive_required_window':0,
          'extra_history_missing_cells':int(s.employment_thousands.isna().sum()),
          'max_required_window_absolute_reconciliation_gap_percent':float(rounding_gap),
          'manual_source_anchor':'BC 2024 total employment = 2914.0 thousand; sum of rounded groups can differ'},
        'classification_cautions':['Resource group combines forestry, fishing, mining, oil and gas; it is not a forestry-only series.',
          'Manufacturing includes all manufacturing, not automotive only.',
          'HHI and LQ describe employment, not exports or comparative advantage.',
          'Historic employment growth variability is not an identified productivity shock or forecast uncertainty.']})
    (package/'source_and_dictionary.json').write_text(json.dumps(metadata,indent=2)+'\n')
    (package/'README.md').write_text('''# Canada: specialization and resilience starter data

Start with the two CSVs and `source_and_dictionary.json`. Downloaded November 4,
2026 from Statistics Canada Table 14-10-0023-01. This is a filtered course extract
of published values, not the original full Statistics Canada file. The full
source download and checksum are recorded in the dictionary. No values are
invented or filled in. Reproduction script: `prepare_starter.py`.

## Your work

Use 2010–2024 for the common assignment; 2000–2025 is supplied for optional
sensitivity. Choose one province plus two comparison provinces and Canada.
Compute shares, concentration, growth variability and a covariance-aware
fixed-weight historical mix. Create your own exhibits and policy argument.
The package deliberately does not contain completed results or a ranking.

Employment is in THOUSANDS. There are 16 non-overlapping industry groups. Total
employment is a separate audit file and must never be added as a seventeenth
industry. Preserve status/symbol flags. The two missing utility observations in
PEI in 2000–2001 are suppressed, not zero; the required 2010–2024 window is complete.
Group totals differ slightly from the published total due to rounding. Report
coverage instead of silently changing data. National estimates are a separate
geography; do not add Canada to the provincial values.

The resource group combines forestry, fishing, mining, quarrying, oil and gas.
Manufacturing is broad. Neither identifies a specific cluster's employment.
Mean employment growth is not productivity, a financial return or welfare.
Employment concentration is not export RCA. Big industries are not evidence of
increasing returns. The assignment's historical reweighting is not a forecast.

## Suggested project folders

`data/raw/`, `data/processed/`, `code/`, `figures/`, `memo/`

Keep these starter files unchanged under `data/raw`. Record download access
date and hashes. Make analysis outputs in `data/processed`. Verify at least
three cells against the original source. Save a source audit, verification
report, AI log and both partners' contributions in the research ZIP.
''')
    import shutil
    shutil.copy2(Path(__file__), package/'prepare_starter.py')
    out=ROOT.parents[1]/'output/podcast/canada-specialization-risk'
    out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out/'canada_specialization_starter.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(package.iterdir()): z.write(f,f.name)
    manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in package.iterdir() if f.is_file()}
    (ROOT/'starter_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Starter rows',len(s),'required-window rows',len(required),'maximum rounding gap %',rounding_gap)
    print('Created',out/'canada_specialization_starter.zip')

if __name__=='__main__': main()
