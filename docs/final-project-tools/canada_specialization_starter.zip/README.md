# Canada: specialization and resilience starter data

Start with the two CSVs and `source_and_dictionary.json`. Downloaded November 4,
2026 from Statistics Canada Table 14-10-0023-01. This is a filtered course extract
of published values, not the original full Statistics Canada file. The full
source download and checksum are recorded in the dictionary. No values are
invented or filled in. Reproduction script: `prepare_starter.py`.

## Your work

Use 2010–2024 for the common assignment; 2000–2025 is supplied for optional
sensitivity. Choose one province plus two comparison provinces and Canada.
Compute shares, concentration, growth variability and a covariance-aware
fixed-weight historical mix. Create your own exhibits and policy argument.
The package deliberately does not contain completed results or a ranking.

Employment is in THOUSANDS. There are 16 non-overlapping industry groups. Total
employment is a separate audit file and must never be added as a seventeenth
industry. Preserve status/symbol flags. The two missing utility observations in
PEI in 2000–2001 are suppressed, not zero; the required 2010–2024 window is complete.
Group totals differ slightly from the published total due to rounding. Report
coverage instead of silently changing data. National estimates are a separate
geography; do not add Canada to the provincial values.

The resource group combines forestry, fishing, mining, quarrying, oil and gas.
Manufacturing is broad. Neither identifies a specific cluster's employment.
Mean employment growth is not productivity, a financial return or welfare.
Employment concentration is not export RCA. Big industries are not evidence of
increasing returns. The assignment's historical reweighting is not a forecast.

## Suggested project folders

`data/raw/`, `data/processed/`, `code/`, `figures/`, `memo/`

Keep these starter files unchanged under `data/raw`. Record download access
date and hashes. Make analysis outputs in `data/processed`. Verify at least
three cells against the original source. Save a source audit, verification
report, AI log and both partners' contributions in the research ZIP.
